from pyspark.ml import Pipeline
from pyspark.ml.classification import LogisticRegression, DecisionTreeClassifier, RandomForestClassifier
from pyspark.ml.evaluation import MulticlassClassificationEvaluator, BinaryClassificationEvaluator
from pyspark.ml.feature import VectorAssembler, StringIndexer
from pyspark.ml.stat import ChiSquareTest
from pyspark.ml.tuning import ParamGridBuilder, CrossValidator
import pyspark.sql.functions as F
from pyspark.sql.functions import col, udf
from pyspark.sql.types import DoubleType, StringType, IntegerType

from src.dependencies.model import columns, indexed_columns, categorical_columns, binary_columns, numerical_columns
from src.dependencies.spark import start
from src.dependencies.transofrmers.LabelTransformers import LabelBinaryConverter, LabelMulticlassConverter


def main():
    spark, config = start(
        app_name='ml_job',
        files=['config/etl_config.json']
    )
    test_data = define_dataframe(extract_data(spark, config['test_path'], 16))
    training_data = define_dataframe(extract_data(spark, config['training_path'], 16))

    label_pipeline = Pipeline(stages=[LabelBinaryConverter(),
                                      LabelMulticlassConverter(),
                                      StringIndexer(inputCol="labelBinary", outputCol="labelBinary_index"),
                                      StringIndexer(inputCol="labelMulti", outputCol="labelMulti_index")])
    label_pipeline = label_pipeline.fit(training_data)

    test_data = label_pipeline.transform(test_data)
    training_data = label_pipeline.transform(training_data)

    training_data, ohe_cols = index_strings_with_udf(training_data, categorical_columns)
    test_data, ohe_cols = index_strings_with_udf(test_data, categorical_columns)

    training_data = training_data.cache()
    test_data = test_data.cache()

    va = VectorAssembler(inputCols=ohe_cols + binary_columns + numerical_columns,
                         outputCol='features')
    training_data = va.transform(training_data) \
        .select("features", "labelBinary_index")
    test_data = va.transform(test_data) \
        .select("features", "labelBinary_index")

    training_data.show()
    svm_result = random_forest(training_data, test_data)
    svm_result.show()
    evaluator = MulticlassClassificationEvaluator(metricName="accuracy", labelCol="labelBinary_index")
    evaluator = BinaryClassificationEvaluator(labelCol="labelBinary_index")
    print(evaluator.evaluate(svm_result))


def feature_selection_chi_square(training_data):
    va = VectorAssembler(inputCols=indexed_columns, outputCol='features')
    training_data = va.transform(training_data) \
        .select("features", "label")
    result = ChiSquareTest.test(training_data, 'features', 'label')
    print("pvalues: " + str(result.select('pValues').collect()))


def extract_data(spark, path, partition):
    dataset_rdd = spark \
        .sparkContext \
        .textFile(path, partition) \
        .map(lambda line: line.split(','))
    return dataset_rdd


def define_dataframe(rdd):
    df = (rdd.toDF(columns)).select(
        col('duration').cast(DoubleType()),
        col('protocol_type').cast(StringType()),
        col('service').cast(StringType()),
        col('flag').cast(StringType()),
        col('src_bytes').cast(DoubleType()),
        col('dst_bytes').cast(DoubleType()),
        col('land').cast(DoubleType()),
        col('wrong_fragment').cast(DoubleType()),
        col('urgent').cast(DoubleType()),
        col('hot').cast(DoubleType()),
        col('num_failed_logins').cast(DoubleType()),
        col('logged_in').cast(DoubleType()),
        col('num_compromised').cast(DoubleType()),
        col('root_shell').cast(DoubleType()),
        col('su_attempted').cast(DoubleType()),
        col('num_root').cast(DoubleType()),
        col('num_file_creations').cast(DoubleType()),
        col('num_shells').cast(DoubleType()),
        col('num_access_files').cast(DoubleType()),
        col('num_outbound_cmds').cast(DoubleType()),
        col('is_host_login').cast(DoubleType()),
        col('is_guest_login').cast(DoubleType()),
        col('count').cast(DoubleType()),
        col('srv_count').cast(DoubleType()),
        col('serror_rate').cast(DoubleType()),
        col('srv_serror_rate').cast(DoubleType()),
        col('rerror_rate').cast(DoubleType()),
        col('srv_rerror_rate').cast(DoubleType()),
        col('same_srv_rate').cast(DoubleType()),
        col('diff_srv_rate').cast(DoubleType()),
        col('srv_diff_host_rate').cast(DoubleType()),
        col('dst_host_count').cast(DoubleType()),
        col('dst_host_srv_count').cast(DoubleType()),
        col('dst_host_same_srv_rate').cast(DoubleType()),
        col('dst_host_diff_srv_rate').cast(DoubleType()),
        col('dst_host_same_src_port_rate').cast(DoubleType()),
        col('dst_host_srv_diff_host_rate').cast(DoubleType()),
        col('dst_host_serror_rate').cast(DoubleType()),
        col('dst_host_srv_serror_rate').cast(DoubleType()),
        col('dst_host_rerror_rate').cast(DoubleType()),
        col('dst_host_srv_rerror_rate').cast(DoubleType()),
        col('labels').cast(StringType())
    )
    return df


# 1 - attack
# 0 - normal


def index_strings(df, labels):
    ohe_cols = []
    for label in labels:
        unique_values = df.select(label).distinct().rdd.flatMap(lambda x: x).collect()
        for value in unique_values:
            ohe_cols.append(label + "_" + value)
        expr = [F.when(F.col(label) == value, 1).otherwise(0).alias(label + "_" + value) for value in unique_values]
        df = df.select("*", *expr)
    return df.drop(*labels), ohe_cols


def index_strings_with_udf(df, labels):
    ohe_cols = []
    for label in labels:
        distinct_values = df.select(label).distinct().rdd.flatMap(lambda x: x).collect()
        for distinct_value in distinct_values:
            pivot_udf = udf(lambda item: 1 if item == distinct_value else 0, IntegerType())
            column_name = label + "_" + distinct_value
            ohe_cols.append(column_name)
            df = df.withColumn(column_name, pivot_udf(col(label)))
    return df.drop(*labels), ohe_cols


def svm_linear(train_df, test_df):
    lsvc = LogisticRegression(labelCol="label")
    # param_grid = ParamGridBuilder() \
    #     .addGrid(lsvc.regParam, [0.01,0.1, 0.5]) \
    #     .addGrid(lsvc.maxIter, [10, 20, 30, 40, 50]) \
    #     .build()
    # cross_validator = CrossValidator(estimator=lsvc,
    #                                  numFolds=3,
    #                                  estimatorParamMaps=param_grid,
    #                                  evaluator=BinaryClassificationEvaluator())
    lsvc = lsvc.fit(test_df)
    return lsvc.transform(train_df)


def svm_multiclass(train_df, test_df):
    lr = LogisticRegression()
    param_grid = ParamGridBuilder() \
        .addGrid(lr.regParam, [0.1, 0.01, 0.05]) \
        .addGrid(lr.maxIter, [10, 20, 30, 40, 50]) \
        .addGrid(lr.elasticNetParam, [0.2, 0.5, 0.8]) \
        .build()
    cross_validator = CrossValidator(estimator=lr,
                                     numFolds=3,
                                     estimatorParamMaps=param_grid,
                                     evaluator=MulticlassClassificationEvaluator())
    lsvc = cross_validator.fit(train_df)
    return lsvc.transform(test_df)


def decision_tree(train_df, test_df):
    dt = DecisionTreeClassifier(labelCol='label', featuresCol='features', maxDepth=2, maxBins=80)
    dt_param_grid = ParamGridBuilder() \
        .addGrid(dt.maxDepth, [2, 5, 10, 20, 30]) \
        .addGrid(dt.maxBins, [80, 100, 120]) \
        .build()
    dtcv = CrossValidator(estimator=dt,
                          estimatorParamMaps=dt_param_grid,
                          evaluator=BinaryClassificationEvaluator(rawPredictionCol="rawPrediction"),
                          numFolds=5)
    dtcv_model = dtcv.fit(train_df)
    return dtcv_model.transform(test_df)


def random_forest(train_df, test_df):
    rf = RandomForestClassifier(featuresCol='features', labelCol='labelBinary_index', maxBins=70)
    rfModel = rf.fit(train_df)
    return rfModel.transform(test_df)


def gradient_boosting(df):
    pass


def hybrid(df):
    pass


if __name__ == '__main__':
    main()
